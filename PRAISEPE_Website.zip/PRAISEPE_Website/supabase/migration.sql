-- PRAISEP&E backend (tables prefixed pe_ because the Supabase project is shared with other sites)
create table if not exists public.pe_admins (email text primary key, added_at timestamptz not null default now());
alter table public.pe_admins enable row level security;
insert into public.pe_admins (email) values
  ('olusholaakinkunmi2016@gmail.com'),('osenluv@yahoo.co.uk'),('akinkunmitimileyinpraise@gmail.com')
on conflict (email) do nothing;

create or replace function public.pe_is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.pe_admins a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email','')))
  and exists (select 1 from jsonb_array_elements(coalesce(auth.jwt() -> 'amr','[]'::jsonb)) m where m ->> 'method' in ('otp','magiclink'));
$$;
revoke all on function public.pe_is_admin() from public, anon;
grant execute on function public.pe_is_admin() to authenticated;

create table if not exists public.pe_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, phone text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now());
alter table public.pe_profiles enable row level security;

create table if not exists public.pe_enquiries (
  id uuid primary key default gen_random_uuid(),
  reference text generated always as ('PE-' || upper(substr(replace(id::text,'-',''),1,8))) stored,
  user_id uuid references auth.users(id) on delete set null,
  source text not null default 'contact' check (source in ('contact','planner')),
  name text not null, email text not null, phone text, subject text, project_area text,
  site_type text, location text, timeline text, message text not null,
  status text not null default 'new' check (status in ('new','in_progress','quoted','won','closed','spam')),
  admin_notes text, email_status text not null default 'pending', ip_hash text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now());
alter table public.pe_enquiries enable row level security;
create index if not exists pe_enquiries_created_idx on public.pe_enquiries (created_at desc);
create index if not exists pe_enquiries_email_idx on public.pe_enquiries (lower(email), created_at desc);
create index if not exists pe_enquiries_user_idx on public.pe_enquiries (user_id);
create index if not exists pe_enquiries_ip_idx on public.pe_enquiries (ip_hash, created_at desc);

create or replace function public.pe_touch_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists pe_enquiries_touch on public.pe_enquiries;
create trigger pe_enquiries_touch before update on public.pe_enquiries for each row execute function public.pe_touch_updated_at();
drop trigger if exists pe_profiles_touch on public.pe_profiles;
create trigger pe_profiles_touch before update on public.pe_profiles for each row execute function public.pe_touch_updated_at();

create policy "admins read admins" on public.pe_admins for select to authenticated using (public.pe_is_admin());
create policy "admins add admins" on public.pe_admins for insert to authenticated with check (public.pe_is_admin());
create policy "admins remove other admins" on public.pe_admins for delete to authenticated
  using (public.pe_is_admin() and lower(email) <> lower(coalesce(auth.jwt() ->> 'email','')));
create policy "own profile read" on public.pe_profiles for select to authenticated using (id = auth.uid() or public.pe_is_admin());
create policy "own profile insert" on public.pe_profiles for insert to authenticated with check (id = auth.uid());
create policy "own profile update" on public.pe_profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "customers read own enquiries" on public.pe_enquiries for select to authenticated using (user_id = auth.uid() or public.pe_is_admin());
create policy "admins update enquiries" on public.pe_enquiries for update to authenticated using (public.pe_is_admin()) with check (public.pe_is_admin());
create policy "admins delete enquiries" on public.pe_enquiries for delete to authenticated using (public.pe_is_admin());
alter publication supabase_realtime add table public.pe_enquiries;
