import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const clean = (v: unknown, max: number) =>
  typeof v === "string" ? v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, max) : "";
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return json({ ok: false, error: "Invalid request" }, 400); }
  if (clean(body.website, 200)) return json({ ok: true, reference: "PE-00000000" }); // honeypot

  const name = clean(body.name, 120);
  const email = clean(body.email, 200).toLowerCase();
  const phone = clean(body.phone, 40);
  const message = clean(body.message, 4000);
  const source = body.source === "planner" ? "planner" : "contact";
  if (name.length < 2) return json({ ok: false, error: "Please enter your name." }, 422);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return json({ ok: false, error: "Please enter a valid email address." }, 422);
  if (phone && !/^[0-9+()\-\s]{6,25}$/.test(phone)) return json({ ok: false, error: "Please enter a valid phone number." }, 422);
  if (message.length < 10) return json({ ok: false, error: "Please describe your enquiry in a little more detail." }, 422);

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const ip = (req.headers.get("x-forwarded-for") || "unknown").split(",")[0].trim();
  const ipHash = await sha256("pe|" + ip);
  const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const [{ count: byEmail }, { count: byIp }] = await Promise.all([
    admin.from("pe_enquiries").select("id", { count: "exact", head: true }).eq("email", email).gte("created_at", since),
    admin.from("pe_enquiries").select("id", { count: "exact", head: true }).eq("ip_hash", ipHash).gte("created_at", since),
  ]);
  if ((byEmail ?? 0) >= 5 || (byIp ?? 0) >= 10)
    return json({ ok: false, error: "Too many enquiries in a short time. Please try again later or contact us on WhatsApp." }, 429);

  let userId: string | null = null;
  const auth = req.headers.get("authorization") || "";
  if (auth.startsWith("Bearer ")) {
    const { data } = await admin.auth.getUser(auth.slice(7));
    userId = data?.user?.id ?? null;
  }
  const row = {
    user_id: userId, source, name, email, phone: phone || null,
    subject: clean(body.subject, 160) || null, project_area: clean(body.project_area, 120) || null,
    site_type: clean(body.site_type, 120) || null, location: clean(body.location, 200) || null,
    timeline: clean(body.timeline, 120) || null, message, ip_hash: ipHash,
  };
  const { data: saved, error } = await admin.from("pe_enquiries").insert(row).select("id, reference").single();
  if (error || !saved) {
    console.error("insert failed", error);
    return json({ ok: false, error: "We could not save your enquiry. Please try again or use WhatsApp." }, 500);
  }

  // Optional email alert: set secret RESEND_API_KEY (and RESEND_FROM for a verified sender)
  let emailStatus = "not_configured";
  const resendKey = Deno.env.get("RESEND_API_KEY");
  if (resendKey) {
    try {
      const { data: admins } = await admin.from("pe_admins").select("email");
      const to = (admins ?? []).map((a: { email: string }) => a.email);
      const from = Deno.env.get("RESEND_FROM") || "PRAISEP&E Website <onboarding@resend.dev>";
      const lines = [["Reference", saved.reference], ["Type", source === "planner" ? "Project planner" : "Contact form"],
        ["Name", name], ["Email", email], ["Phone", phone || "-"], ["Subject", row.subject || "-"],
        ["Project area", row.project_area || "-"], ["Site type", row.site_type || "-"],
        ["Location", row.location || "-"], ["Timeline", row.timeline || "-"]];
      const html = `<h2>New website enquiry</h2><table cellpadding="6">${lines.map(([k, v]) => `<tr><td><b>${k}</b></td><td>${esc(String(v))}</td></tr>`).join("")}</table><p style="white-space:pre-wrap">${esc(message)}</p>`;
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from, to, reply_to: email, subject: `New enquiry ${saved.reference} from ${name}`, html }),
      });
      emailStatus = r.ok ? "sent" : "failed";
      if (!r.ok) console.error("resend error", r.status, await r.text());
    } catch (e) { console.error("email error", e); emailStatus = "failed"; }
  }
  await admin.from("pe_enquiries").update({ email_status: emailStatus }).eq("id", saved.id);
  return json({ ok: true, reference: saved.reference });
});
