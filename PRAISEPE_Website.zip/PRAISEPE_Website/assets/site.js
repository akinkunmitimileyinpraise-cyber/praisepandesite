(function(){
var page=document.body.getAttribute('data-page');
document.querySelectorAll('.nav a[data-page]').forEach(function(a){if(a.dataset.page===page)a.classList.add('active');});
var menuButton=document.querySelector('.menu-toggle'),nav=document.querySelector('.nav');
if(menuButton&&nav){menuButton.addEventListener('click',function(){var o=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(o));});}
document.querySelectorAll('.nav a').forEach(function(a){a.addEventListener('click',function(){if(nav)nav.classList.remove('open');if(menuButton)menuButton.setAttribute('aria-expanded','false');});});
document.querySelectorAll('.faq-item button').forEach(function(b){b.addEventListener('click',function(){b.parentElement.classList.toggle('open');});});
document.querySelectorAll('.reveal').forEach(function(el){if('IntersectionObserver' in window){var ob=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('visible');ob.unobserve(e.target);}});});ob.observe(el);}else el.classList.add('visible');});
var year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
var items=document.querySelectorAll('.service-card,.project,.testimonial-grid blockquote,.facts div');
if('IntersectionObserver' in window){var obs=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});},{threshold:.12});items.forEach(function(i){i.classList.add('reveal');obs.observe(i);});}
})();
document.addEventListener('error',function(e){var t=e.target;if(t&&t.tagName==='IMG'&&!t.dataset.failed){t.dataset.failed='1';t.style.visibility='hidden';if(t.parentElement)t.parentElement.style.background='linear-gradient(135deg,#0b2a4d,#1683ce)';}},true);
