window.PE=(function(){
var URL_='https://myazxcvyaqyqtrjpghvf.supabase.co',KEY='sb_publishable_IXruQdFSrLiXuawXicX8ww_XbRcC04t',REF='myazxcvyaqyqtrjpghvf';
function session(){try{var s=JSON.parse(localStorage.getItem('sb-'+REF+'-auth-token')||'null');if(s&&s.access_token&&(!s.expires_at||s.expires_at*1000>Date.now()))return s;}catch(e){}return null;}
async function submit(data){
  var h={'Content-Type':'application/json',apikey:KEY},s=session();
  if(s)h.Authorization='Bearer '+s.access_token;
  try{
    var r=await fetch(URL_+'/functions/v1/submit-enquiry',{method:'POST',headers:h,body:JSON.stringify(data)});
    var j=await r.json().catch(function(){return{};});
    if(r.ok&&j.ok)return{ok:true,reference:j.reference};
    return{ok:false,error:j.error||'Something went wrong. Please try again or use WhatsApp.'};
  }catch(e){return{ok:false,error:'Network problem. Please check your connection and try again.'};}
}
function prefill(map){var s=session();if(!s||!s.user)return;var u=s.user,m=u.user_metadata||{};
  if(map.name&&!map.name.value)map.name.value=m.full_name||'';
  if(map.email&&!map.email.value)map.email.value=u.email||'';
  if(map.phone&&!map.phone.value)map.phone.value=m.phone||'';}
return{url:URL_,key:KEY,session:session,submit:submit,prefill:prefill};
})();
