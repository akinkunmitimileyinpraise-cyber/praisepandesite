PRAISEP&E COMMUNICATION LIMITED - website + Supabase backend
=============================================================
Live site: https://praisepande-site.vercel.app   (staff: /admin   customers: /account)

FOLDERS
  *.html, assets/      The website (10 pages + shared CSS/JS + all original photos)
  vercel.json          Clean URLs (/admin, /account) and caching
  supabase/migration.sql                      Tables, security rules, admin emails
  supabase/functions/submit-enquiry/index.ts  Server-side enquiry processing (edge function)

BACKEND (already live)
  Supabase project: myazxcvyaqyqtrjpghvf   (tables pe_enquiries, pe_profiles, pe_admins)
  Staff emails: olusholaakinkunmi2016@gmail.com, osenluv@yahoo.co.uk, akinkunmitimileyinpraise@gmail.com
  Connection details are in assets/pe-api.js (publishable key only - safe for browsers).

TO REDEPLOY
  Upload this whole folder to Vercel (GitHub import, or `vercel --prod` from this folder).
  The live deployment currently has no photos; deploying this folder includes them.

SUPABASE SETTINGS YOU MUST SET (dashboard)
  1. Authentication > URL Configuration: add https://praisepande-site.vercel.app as Site URL + redirect URL.
  2. Authentication > SMTP: set custom SMTP (e.g. Resend) so sign-in/confirmation emails are delivered.
  3. Optional email alerts: Edge Functions > submit-enquiry > Secrets: RESEND_API_KEY (and RESEND_FROM).
